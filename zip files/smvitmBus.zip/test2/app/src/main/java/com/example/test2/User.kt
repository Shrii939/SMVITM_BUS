package com.example.test2

data class User(
    val email: String,
    val username: String,
    val phoneNumber: String,
    val isAdmin: Boolean,
    val isDriver: Boolean
)